//
//  ContactsData.m
//  ContactList
//
//  Created by Balaji Goud on 1/19/17.
//  Copyright © 2017 RBT. All rights reserved.
//

#import "ContactsData.h"

@implementation ContactsData

@end
